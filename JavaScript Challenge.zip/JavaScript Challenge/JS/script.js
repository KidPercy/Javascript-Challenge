
var blueB = document.getElementById("bBox");
var greenB = document. getElementById("gBox");
var redB = document.getElementById("rBox");
var bigBox = document.getElementById("largeBox");
var helloText = document.getElementById("textChanger");
var ascciAddition = document. getElementById("Calculate")

blueB.onclick= function(){

   var blueAscci= 066 +108 +17+101;

   bigBox.style.backgroundColor="blue"; 
   helloText.innerHTML="Hi my name is Blue";

   ascciAddition.innerHTML=blueAscci;



 };

 greenB.onclick= function(){

    var greenAscci= 071 +114 +101+101+110;

	bigBox.style.backgroundColor="green"; 
	helloText.innerHTML="Hi my name is Green";
	ascciAddition.innerHTML=greenAscci;
 };

 redB.onclick= function(){

    var redAscci= 082 +101 +100;

	bigBox.style.backgroundColor="red"; 
	helloText.innerHTML="Hi my name is Red";
	ascciAddition.innerHTML=redAscci;
 };


